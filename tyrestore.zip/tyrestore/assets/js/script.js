"use strict";
const mobileMenuElements = document.getElementsByClassName('mobile-men');

var content = {};
content.opacityIn = [0,1];
content.scaleIn = [0.95, 1];
content.scaleOut = 3;
content.durationIn = 6000;
content.durationOut = 8000;
content.delay = 6000;


anime.timeline({loop: true})
.add({
targets: '.content h1',
opacity: content.opacityIn,
scale: content.scaleIn,
duration: content.durationIn
})


jQuery(document).ready(function($) {
    //  TESTIMONIALS CAROUSEL HOOK
    $('.client').owlCarousel({
        margin:10,
    loop: true,
    autoplay: true,
    autoplayTimeout: 1520,
    smartSpeed: 1500,
    animateIn: 'linear',
    animateOut: 'linear',
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:6
        }
    }
    });
});
           
    // Used bootstrap v4.5,jquery v3.5.1, owl carousel v2, font awesome v4.7.0

    jQuery(document).ready(function($) {
        //  TESTIMONIALS CAROUSEL HOOK
        $('#testi').owlCarousel({
            loop: true,
            
            items: 3,
            margin: 0,
            margin:10,
            autoplay: true,
            dots:true,
            autoplayTimeout: 8500,
            smartSpeed: 450,
            responsive: {
              0: {
                items: 1
              },
              768: {
                items: 2
              },
              1170: {
                items: 2
              }
            }
        });
    });



    function menu() {
        var x = document.getElementsByClassName(".close");
        if (x.style.display === "none") {
          x.style.display = "block";
        } else {
          x.style.display = "none";
        }
      }


